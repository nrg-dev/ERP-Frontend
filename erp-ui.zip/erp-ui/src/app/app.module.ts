import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppRoutingModule } from './app-routing';
import { AppComponent } from './app.component';
import { AlertService, UserService, ServerURL } from './_services/index';
import { AlertComponent } from './_directives/index';
import { fakeBackendProvider } from './_helpers/index';
import { JwtInterceptor } from './_helpers/index';
import { AuthGuard } from './_guards/index';

import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';

@NgModule({
	declarations: [
		AppComponent,
		AlertComponent,
		LoginComponent,
		HeaderComponent
	],
	imports: [
        BrowserModule,
        FormsModule,
        HttpClientModule,
        AppRoutingModule
    ],
	providers: [
		AuthGuard,
        AlertService,
		UserService,
		ServerURL,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: JwtInterceptor,
            multi: true
        },
		fakeBackendProvider
	],
  bootstrap: [AppComponent]
})
export class AppModule { }
