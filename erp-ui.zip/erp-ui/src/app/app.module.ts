import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MDBBootstrapModule } from 'angular-bootstrap-md';

import { AppRoutingModule } from './app-routing';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { LeftmenuComponent } from './leftmenu/leftmenu.component';
import { LandingpageComponent } from './landingpage/landingpage.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    LeftmenuComponent,
    LandingpageComponent
  ],
  imports: [
        MDBBootstrapModule.forRoot(),

    BrowserModule,
    AppRoutingModule,
  ], 
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
