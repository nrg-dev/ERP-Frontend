﻿import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../_models/index';
import { ServerURL } from './url';


@Injectable()
export class UserService {    
    suburl:string;

    private commonURL = this.globalsURL.serverURL;

    constructor(private http: HttpClient, private globalsURL: ServerURL) { }

    /* getAll() {
        return this.http.get<User[]>('/api/users');
    }

    getById(id: number) {
        return this.http.get('/api/users/' + id);
    }  */
 
}
