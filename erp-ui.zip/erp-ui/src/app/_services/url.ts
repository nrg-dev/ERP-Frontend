﻿export class ServerURL  { 
    //public serverURL = 'http://35.162.40.190:8091/user-portal/';
    public serverURL = 'http://localhost:8091/user-portal/';
}
