import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login';
import { HeaderComponent} from './header';
import { LeftmenuComponent } from './leftmenu/leftmenu.component';
import { LandingpageComponent } from './landingpage/landingpage.component';

const routes: Routes = [
  { path: '', component: LandingpageComponent},
  { path: 'login', component: LoginComponent},
  { path: 'header', component:HeaderComponent},

  { path: 'leftmenu', component:LeftmenuComponent},
  { path: 'landingpage', component:LandingpageComponent},

  // otherwise redirect to login
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
