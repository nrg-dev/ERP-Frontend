export class Common {
  username:string;
  password:string;
  country: string;
  address:string;
  status:string;
  phoneNumber:string;
  emailID:string;
}
