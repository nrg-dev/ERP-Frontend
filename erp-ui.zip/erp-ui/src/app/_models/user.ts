﻿import { Common } from "./common";

export class User extends Common{

	id: string; 
  
	currentusername: string;
	currentpassword: string;
	firstName: string;
	lastName: string;
	created_date:any;
}
